# init_db.py
from app import app, db

# Crear las tablas en la base de datos dentro del contexto de la aplicación Flask
with app.app_context():
    db.create_all()
    print("Base de datos y tablas creadas exitosamente.")
